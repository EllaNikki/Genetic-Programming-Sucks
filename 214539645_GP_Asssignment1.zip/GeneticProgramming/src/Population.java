import java.util.*;

public class Population {
	 Random ran=new Random(987654321);
	
	 ArrayList<String>tree=new ArrayList<String>();
	 List<MyTree>popList=new ArrayList<MyTree>();
	
	 String[]FunctionTerminalSet={"+","-","*","/","x","1"};
	/*
	 * First 4 elements are Function Set, the rest are Terminal set.
	 * Terminal set includes a reasonable range of constant numerical terminals
	 */
	    
	
	public Population(){
		
	}
	
	public Population(int population,int max,int method,int func) {
		
		// Display results according to Method Selection
			if(method==3)
	        {
	        	ramped(max,population,func);
	        }
	        else
	        {
	        	System.out.print("Population: "+population+"\nMaximum depth: "+max+"\nMethod: ");
		    	if(method==1)
		    		System.out.println("Grow\n");
		    	else
		    		System.out.println("Full\n");
	        	displayPopulation(population,max,method,func);
	        }
	    } //constructor
	
	// Tree Generation Methods
	    public  void grow(int depth, int max_depth)
	    {    
	    	if(depth==0)
	    	{
	    		Node current=new Node(getRandomF());
	    		tree.add(current.label+"");
	    		for(int i=0;i<current.getArity();i++)
		        {
		           grow(depth+1,max_depth);
		        }
	    	}
	    	else if(depth<max_depth){
	    	Node current=new Node(getRandomTF());
	    	tree.add(current.label+"");
	           
		    	for(int i=0;i<current.getArity();i++)
		        {
		           grow(depth+1,max_depth);
		        }
	    	}
	    	else
	    	{
	    		tree.add((new Node(getRandomT())).label+"");
	    	}
	    }//end grow
	    
	    public  void full(int depth, int max_depth)
	    {    
	    	if(depth<max_depth){
	    	Node current=new Node(getRandomF());
	    	tree.add(current.label+"");
	           
		    	for(int i=0;i<current.getArity();i++)
		        {
		           full(depth+1,max_depth);
		        }
	    	}
	    	else
	    	{
	    		tree.add((new Node(getRandomT())).label+"");
	    	}
	    }//end full
	    
	    public  void ramped(int max_depth, int population,int func)
	    {
	    	int treesPerDepth=population/(max_depth-1); 
	    	int mid=treesPerDepth/2;
	    	
	    	System.out.println("Population: "+population+"\nTrees per depth: "+treesPerDepth
	    			+"\nOf which there are: \n\t"+mid+" Grow\n\t"+mid+" Full\n\t"+treesPerDepth%2
	    			+" Randomly selected method\n\n"+population%(max_depth-1)
	    			+" trees were generated at a random depth and with a randomly selected method\n\n");
	    	
	    	for(int j=2;j<=max_depth;j++) //for each depth j
	    	{
		    	System.out.println("\nDepth "+j+"\n");
		    	
	    		
		    	displayPopulation(mid,j,1,func);
		    	displayPopulation(mid,j,2,func);
		    	
		    	
		    	if(treesPerDepth%2==1) //If trees per depth is odd
		    	{
		    		displayPopulation(1,j,getRandomMethod(),func);
		    	}
	    	}
	    	
	    	System.out.println("\nRandom depth with randomly selected method\n");
	    	
	    	for(int k=0;k<(population%(max_depth-1));k++)
	    	{
	    		displayPopulation(1,getRandomDepth(max_depth),getRandomMethod(),func);
	    	}
	    }//end ramped
	    
	    
	    //Random Methods
	    public  int getRandomMethod(){
	    	
	    	int i=1+ran.nextInt(2);
	    	return i;
	    }
	    
	    public  int getRandomDepth(int max_depth){
	    	
	    	int i=2+ran.nextInt(max_depth-3); //generates a depth between 2 and max depth
	    	return i;
	    }
	    
	    	
	    public  char getRandomTF(){
	    	
	    	char c=(FunctionTerminalSet[ran.nextInt(6)]).charAt(0);
	    	return c;
	    }
	    
	    public  char getRandomT(){
	    	char c=(FunctionTerminalSet[4+(ran.nextInt(2))]).charAt(0);
	    	return c;
	    }
	    
	    public  char getRandomF(){
	    	char c=(FunctionTerminalSet[ran.nextInt(4)]).charAt(0);
	    	return c;
	    }
	    
	    //Display Methods
	    public  void displayTree()
	    {
			Iterator<String> iterator = tree.iterator();
			while(iterator.hasNext())
			{
				System.out.print(iterator.next());
			}
			
	    }
	    
	    public void displayPopulation(int population,int maxDepth,int method,int func)
	    {
	    	for(int i=0;i<population;i++)
	    	{
		    	if(method==1)
		    	{
		    		grow(0,maxDepth);
		    	}
		    	else if(method==2)
		    	{
		    		full(0,maxDepth);	
		    	}
		    	
		    	displayTree();
		    	System.out.println();
		    	popList.add(new MyTree(tree,func));
		    	tree.clear();
	    	}
	    }

	    public List<MyTree> getPopulation()
	    {
	    	return popList;
	    }
	    
	    public String getTree()
	    {
	    	String t="";
	    	for(int i=0;i<tree.size();i++)		
	    	{
	    		t+=tree.get(i);
	    	}
	    	return t;
	    }
	    
	    public  String getSubtree(int maxMutationDepth){
	    	
	    	int mutationDepth = ran.nextInt(maxMutationDepth); //generates a depth between 1 and max depth
	    	
	    	int m=getRandomMethod();
	    	
	    	if(m==1)
	    	{
	    		grow(0,mutationDepth);
	    	}
	    	else if(m==2)
	    	{
	    		full(0,mutationDepth);
	    	}
	    	
	    	String subtree="";
	    	
	    	Iterator<String> iterator = tree.iterator();
			while(iterator.hasNext())
			{
				subtree+=iterator.next();
			}
			tree.clear();
	    	return subtree;
	    }

	    	
	}//end Population


	    