import java.util.Random;

public class GeneticOperators {
	String parent;
	String parent2;
	String offspring;
	String offspring2;
	int mutationDepth;
	int maxOffspringDepth;
	int maxNodes;

	Random ran = new Random(987654321);
	Population p = new Population();

	public GeneticOperators(String p) // reproduce constructor
	{
		parent = p;
		reproduce();
	}

	public GeneticOperators(String p, int mutDepth, int offDepth) // mutation
																	// constructor
	{
		parent = p;
		mutationDepth = mutDepth;
		maxOffspringDepth = offDepth;
		maxNodes = ((int) Math.pow(2, maxOffspringDepth)) - 1;
		mutate();
	}

	public GeneticOperators(String p1, String p2, int offDepth) // crossover
																// constructor
	{
		parent = p1;
		parent2 = p2;
		maxOffspringDepth = offDepth;
		maxNodes = ((int) Math.pow(2, maxOffspringDepth)) - 1;
		// Let T be a binary tree with k levels. Then T has no more than (2^k) �
		// 1 nodes

		crossover();
	}

	public void reproduce() {
		System.out.println("\n\nParent:\t\t" + parent + "\nOffspring:\t" + parent);
	}

	public void mutate() {
		int mutPt = randomPoint(parent);
		String subtree = getSubtree(parent, mutPt);
		int treeLen = parent.length();
		int subLen = subtree.length();

		String newTree;
		do {
			newTree = p.getSubtree(mutationDepth);
			System.out.print("\nAttempting to find offspring with no more than " + maxNodes + " nodes.");
		} while (treeLen - subLen + newTree.length() > maxNodes);

		offspring = (parent.substring(0, mutPt)) + " " + newTree + " "
				+ (parent.substring(mutPt + subtree.length(), parent.length()));

		System.out.println("\n\nParent: " + parent + "\nOffspring: " + offspring + "\n\nMutation position: " + mutPt
				+ "\n\nSubtree to be mutated: " + subtree + "\nNew subtree: " + newTree);
	}

	public void crossover() {
		int crossPt1;
		int crossPt2;
		String subtree1;
		String subtree2;
		int len1 = parent.length();
		int len2 = parent2.length();
		do {
			crossPt1 = randomPoint(parent);
			crossPt2 = randomPoint(parent2);

			subtree1 = getSubtree(parent, crossPt1);
			subtree2 = getSubtree(parent2, crossPt2);
			System.out.print("\nAttempting to find offsprings with no more than " + maxNodes + " nodes.");
		} while ((len1 - subtree1.length() + subtree2.length()) > maxNodes
				|| (len2 - subtree2.length() + subtree1.length()) > maxNodes);

		offspring = (parent.substring(0, crossPt1)) + " " + (subtree2) + " "
				+ (parent.substring(crossPt1 + subtree1.length(), len1));
		offspring2 = (parent2.substring(0, crossPt2)) + " " + (subtree1) + " "
				+ (parent2.substring(crossPt2 + subtree2.length(), len2));

		System.out.println("\n\nParent 1: " + parent + "\nParent 2: " + parent2 + "\n\nOffspring 1: " + offspring
				+ "\nOffspring 2: " + offspring2 + "\n\nCrossover position 1: " + crossPt1 + "\nCrossover position 2: "
				+ crossPt2 + "\n\nSubtree 1: " + subtree1 + "\nSubtree 2: " + subtree2);
	}

	public int randomPoint(String p) {
		int r = ran.nextInt(p.length());
		return r;
	}

	public String getSubtree(String p, int pos) {
		char c = p.charAt(pos);
		switch (c) {

		case '+':
		case '-':
		case '*':
		case '/':
			return c + getSubtree(p, pos + 1) + getSubtree(p, pos + 2); // since arity is 2 for + - * /

		case 'x':
		case '1':
			return "" + c;

		}// switch
		return "";
	}

}// end GeneticOperators class
