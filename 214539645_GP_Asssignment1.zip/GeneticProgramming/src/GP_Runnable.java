import java.util.*;

public class GP_Runnable {
public static void main(String[] args) {
	    
		UserInput input=new UserInput();
        int popSize=input.getPop();
        int max=input.getMax();
        int method=input.getMeth();
        int tournament=input.getTournamentSize(popSize);
        int function=input.getFn();
        int genOp=input.getGen();
        
        
        GeneticOperators g;
        
        Population p=new Population(popSize,max,method,function);
        List<MyTree> population= p.getPopulation();
        Tournament t=new Tournament(population,tournament);
        
        if(genOp==1) //reproduction
        {
        	g=new GeneticOperators(t.newTournament());
        }
        else
        {
        	int offspringDepth=input.getOffspring(max);
        	
        	if(genOp==2) // Mutation
        	{
        		g=new GeneticOperators(t.newTournament(),input.getMutDepth(max),offspringDepth);
        	}
        	
        	else if(genOp==3) // Crossover
        	{
        		g=new GeneticOperators(t.newTournament(),t.newTournament(),offspringDepth);
        	}
        	
        }
        
        
        
        
	}
}
