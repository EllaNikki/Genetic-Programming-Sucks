Hi!

To run from command prompt:

Step 1
Type:	cd (filepath to folder in which you unzipped this folder) followed by "\GeneticProgramming" which is the name of this folder.
eg. 	cd C:\Users\danie\Desktop\GeneticProgramming

Step 2
Type:	java -jar 214539645_Assignment1.jar

Wow! It runs!

Notes regarding output:
1. max mutation depth < max initial depth < max offspring depth

2. If after mutation/crossover the offspring is over-sized (exceeds max offspring depth), 
	there is a loop that doesn't allow this offspring and a new offspring is created. 
	Each over-sized check is represented by the output string:
	"Attempting to find offspring with no more than " + maxNodes + " nodes."
  
3. The parent and offspring is displayed along with the mutation/crossover points if applicable.
	I have flanked the change at the selected point by whitespaces in the display of offspring.
	eg. mutationPosition @ node 2 
		parent 		=  +-xx+x1
		offspring	=  + x +x1      instead of +x+x1 to aid in readability for demonstration purposes in this part 
		subtree to be removed:  -xx
		new subtree :			x 

	I will definitely remove the spaces in part 4. This was just to help you easy locate node 94 for example.
	
4. Maximum offspring size, according to the notes you uploaded, is either a max depth or a max number of nodes.
	I have opted to use max number of nodes as the max offspring size.
	This is calculated by allowing the user to enter a max offspring depth and calculating the max no. of nodes using the theorem:
	Let T be a binary tree with k levels. Then T has no more than (2^k) � 1 nodes.
	If an offspring exceeds the max number of nodes then it is not accepted as discussed in point 2 above.
	 
Bye for now :)