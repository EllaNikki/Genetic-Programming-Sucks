Hi!
There is a .txt file for each Funtion's Fitness Cases.
It contains the expected output for x=1...x=4
These files are stored in the project's src folder.
The program allows the user to choose a function to work towards.
Bye for now :)