import java.util.*;

public class GP_Runnable {
public static void main(String[] args) {
	    
		UserInput input=new UserInput();
        int popSize=input.getPop();
        int max=input.getMax();
        int method=input.getMeth();
        int tournament=input.getTournamentSize(popSize);
        int function=input.getFn();
        
        Population p=new Population(popSize,max,method,function);
        
        List<MyTree> population= p.getPopulation();
      
        Tournament t=new Tournament(population,tournament);
	}
}
