import java.util.*;

public class GeneticOperators {
	String parent;
	String parent2;
	String offspring;
	String offspring2;
	
	int maxOffspringSize;
	int mutationDepth;
	
	Random ran=new Random(987654321);
	
	
	
	public GeneticOperators(String p)
	{
		parent=p;
		reproduce();
	}
	
	public GeneticOperators(String p, int mutDepth, String newtree)
	{
		parent=p;
		mutationDepth=mutDepth;
		mutate(newtree);
	}
	
	public GeneticOperators(String p1,String p2)
	{
		parent=p1;
		parent2=p2;
		crossover();
	}
	
	public void reproduce()
	{
		System.out.println("Parent: "+parent+"\nOffspring: "+parent);
	}
	
	public void mutate(String newTree)
	{
		int mutPt=randomPoint(parent);
		String subtree=getSubtree(parent,mutPt);
		offspring =(parent.substring(0,mutPt)) + " " + newTree +" " + (parent.substring(mutPt+subtree.length(),parent.length())) ;
		
		System.out.println("Parent: "+parent+"\nOffspring: "+offspring
				+"\n\nMutation position: "+mutPt+"\n\nSubtree to be mutated: "+subtree+"\nNew subtree: "+newTree);
	}
	
	public void crossover()
	{
		int crossPt1=randomPoint(parent);
		int crossPt2=randomPoint(parent2);
		
		String subtree1=getSubtree(parent,crossPt1);
		String subtree2=getSubtree(parent2,crossPt2);
		
		offspring =(parent.substring(0,crossPt1)) + " " + (subtree2) +" " + (parent.substring(crossPt1+subtree1.length(),parent.length())) ;
		offspring2=(parent2.substring(0,crossPt2)) +" " + (subtree1) +" " + (parent2.substring(crossPt2+subtree2.length(),parent2.length())) ;
		
		System.out.println("Parent 1: "+parent+"\nParent 2: "+parent2+"\n\nOffspring 1: "+offspring+"\nOffspring 2: "+offspring2
				+ "\n\nCrossover position 1: "+crossPt1+"\nCrossover position 2: "+crossPt2 
				+ "\n\nSubtree 1: "+subtree1+"\nSubtree 2: "+subtree2);
	}
	
	public int randomPoint(String p)
	{
    	int r=ran.nextInt(p.length());
    	return r;
	}
	
	public String getSubtree(String p, int pos)
	{
		char c=p.charAt(pos);
		switch(c)
		{
		
		case '+':
		case '-':
		case '*':
		case '/':   return c + getSubtree(p, pos+1) + getSubtree(p, pos+2);	//since arity is 2 for + - * /
		
		case 'x':
		case '1':	return ""+c;
		
		}//switch
		return "";
	}

}//end GeneticOperators class

