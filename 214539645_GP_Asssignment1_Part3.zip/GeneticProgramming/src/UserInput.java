import javax.swing.JOptionPane;

public class UserInput {
	
	boolean flag=false;
	int population;
    int method;
    int max;
    int tournament;
    int function;
    
	
	public int getPop()
	{
		String pop=JOptionPane.showInputDialog(null,"Initial Population Generator\n\nPlease enter the population size.","Population Size",JOptionPane.QUESTION_MESSAGE);
		while(!flag)
        {
        	try
        	{
        		this.population=Integer.parseInt(pop);
        		if(population>=10&&population<=100)
        			flag=true;
        		else
        			pop=JOptionPane.showInputDialog(null,"Please enter the population size between 10 and 100.","Population Size",JOptionPane.ERROR_MESSAGE);
            	
        	}
        	catch(Exception e){
        		pop=JOptionPane.showInputDialog(null,"Please enter the population size between 10 and 100.","Population Size",JOptionPane.ERROR_MESSAGE);
        	}
        }//end method while loop
		flag=false;
		return population;
	}
	
	public int getMax()
	{
		String maximum=JOptionPane.showInputDialog(null,"Please enter the desired maximum depth.","Maximum depth",JOptionPane.QUESTION_MESSAGE);
		while(!flag)
        {
        	try
        	{
        		max=Integer.parseInt(maximum);
        		if(max>=2&&max<=10)
        			flag=true;
        		else
        			maximum=JOptionPane.showInputDialog(null,"Please enter the Maximum depth size between 2 and 10.","Maximum depth",JOptionPane.ERROR_MESSAGE);
            	
        	}
        	catch(Exception e){
        		maximum=JOptionPane.showInputDialog(null,"Please enter the Maximum depth size between 2 and 10.","Maximum depth",JOptionPane.ERROR_MESSAGE);
        	}
        }//end max while loop
		flag=false;
		return max;
	}
	
	public int getMeth()
	{
		String meth=JOptionPane.showInputDialog(null,"Please enter the method of tree generation.\n1. Grow Method\n2.Full Method\n3.Ramped Half and Half","Generation Method",JOptionPane.QUESTION_MESSAGE);
		while(!flag)
        {
        	try
        	{
        		method=Integer.parseInt(meth);
        		if(method==1||method==2||method==3)
        			flag=true;
        		else
        			meth=JOptionPane.showInputDialog(null,"Please enter the method of tree generation.\n1. Grow Method\n2.Full Method\n3.Ramped Half and Half\nEnter either option 1, 2 or 3.","Generation Method",JOptionPane.ERROR_MESSAGE);
            	
        	}
        	catch(Exception e){
        		meth=JOptionPane.showInputDialog(null,"Please enter the method of tree generation.\n1. Grow Method\n2.Full Method\n3.Ramped Half and Half\nEnter either option 1, 2 or 3.","Generation Method",JOptionPane.ERROR_MESSAGE);
        	}
        }//end method while loop
		flag=false;
		return method;
	}
	
	public int getTournamentSize(int pop)
	{
		String tour=JOptionPane.showInputDialog(null,"Please enter the tournament size.","Tournament Size",JOptionPane.QUESTION_MESSAGE);
		while(!flag)
        {
        	try
        	{
        		tournament=Integer.parseInt(tour);
        		if(tournament<=pop&&tournament>=2)
        			flag=true;
        		else
        			tour=JOptionPane.showInputDialog(null,"Please enter the tournament size that is within your population size but greater than 2.","Tournament Size",JOptionPane.ERROR_MESSAGE);
            	
        	}
        	catch(Exception e){
        		tour=JOptionPane.showInputDialog(null,"Please enter the tournament size that is within your population size but greater than 2.","Tournament Size",JOptionPane.ERROR_MESSAGE);
        	}
        }//end max while loop
		flag=false;
		return tournament;
		}
	
	public int getFn()
	{
		String fn=JOptionPane.showInputDialog(null,"Please enter the Function you would like to work towards.\n1. x^4 + x^3 + x^2 +1\n2. x^6 - 2x^4 + x^2 + 1\n3. x^6 + x^5 + x^4 + x^3 + x^2 + x","Function",JOptionPane.QUESTION_MESSAGE);
		while(!flag)
        {
        	try
        	{
        		function=Integer.parseInt(fn);
        		if(function==1||function==2||function==3)
        			flag=true;
        		else
        			fn=JOptionPane.showInputDialog(null,"Please enter the Function you would like to work towards.\n1. x^4 + x^3 + x^2 +1\n2. x^6 - 2x^4 + x^2 + 1\n3. x^6 + x^5 + x^4 + x^3 + x^2 + x\nEnter either option 1, 2 or 3.","Function",JOptionPane.ERROR_MESSAGE);
            	
        	}
        	catch(Exception e){
        		fn=JOptionPane.showInputDialog(null,"Please enter the Function you would like to work towards.\n1. x^4 + x^3 + x^2 +1\n2. x^6 - 2x^4 + x^2 + 1\n3. x^6 + x^5 + x^4 + x^3 + x^2 + x\nEnter either option 1, 2 or 3.","Function",JOptionPane.ERROR_MESSAGE);
        	}
        }//end method while loop
		flag=false;
		return function;
	}
	
}//end user input class
