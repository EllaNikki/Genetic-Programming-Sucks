
public class Node {
    char label;
    int arity=0;
    
    Node(char label) {
        this.label = label;
        
        switch(label){
        case '+':
        case '-':
        case '*':
        case '/':	arity=2;
        break;
        }
    }
    
    public char getLabel(){
		return label;
	}
	
	public int getArity(){
		return arity;
	}
	
	

}//end Node Class
