import java.util.*;

public class Tournament {
	static Random ran=new Random(987654321);
	List<MyTree>participants;
	
	
	
	public Tournament(List<MyTree> pop,int tourSize)
	{
		participants=getParticipants(pop, tourSize);
		displayWinner(participants);
	}
	
	public List<MyTree> getParticipants(List<MyTree> pop,int tourSize)
	{
		List<MyTree> list=new ArrayList<MyTree>();
		
		for(int i=0;i<tourSize;i++)
		{
			list.add(pop.get(ran.nextInt(pop.size())));
		}
		
		return list;
	}
	
	public MyTree winner(List<MyTree> l)
	{
		double lowest=l.get(0).rawFitness;
		int pos=0;
		for(int i=0;i<l.size();i++)
		{
			if((l.get(i)).rawFitness<lowest)
			{
				lowest=(l.get(i)).rawFitness;
				pos=i;
			}
		}
		return l.get(pos);
	}
	
	public void displayWinner(List<MyTree> l)
	{
		MyTree winner=winner(l);
		
		System.out.println("\n\nFITNESS\t\tTOURNAMENT PARTICIPANTS:\n");
		for(int i=0;i<l.size();i++)
		{
			System.out.print("\n"+Math.round(l.get(i).rawFitness)+"\t\t");
			l.get(i).displayTree();
		}
		System.out.print("\n\n The Winner is:\n"+Math.round(winner.rawFitness)+"\t\t");
		winner.displayTree();
	}


}