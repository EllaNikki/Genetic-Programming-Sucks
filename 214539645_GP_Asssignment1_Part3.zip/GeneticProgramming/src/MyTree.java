import java.io.*;
import java.util.*;

public class MyTree {
	String[]tree;
	int pos=0;
	int hitsRatio=0;
	double rawFitness=0;
	
	public MyTree(ArrayList<String> t,int fn){
		tree=t.toArray(new String[t.size()]);
		readFromFile(fn);
		System.out.println("Raw Fitness: "+Math.round(rawFitness)+"\nHits Ratio: "+hitsRatio+"\n");
		
	}
	
	
	public double evaluate(double x) 
	{
    	Deque<Double> stack = new ArrayDeque<>();
    	
        for(int i=tree.length-1;i>-1;i--)
        {
            
        	String s = tree[i];
            
        	if(s.equals(""))
        	{
                continue;
            }
        	
            if(s.equals("+"))
            {
                stack.push(stack.poll()+stack.poll());
            }
            
            else if(s.equals("*"))
            {
                stack.push(stack.poll() * stack.poll());
            }
            
            else if(s.equals("-"))
            {
                stack.push(stack.poll() - stack.poll());
            }
            
            else if(s.equals("/"))
            {
                try
                {
            	
                	//stack.push(stack.poll() / stack.poll());
                	double divA=stack.poll();
                	double divB=stack.poll();
                	if(divB==0)
                		divB=1.0;
                	stack.push(divA / divB);
                	
                }
                catch(Exception e)
                {
                	stack.push(1.0);
                }
            }
            
            else if(s.equals("x"))
            {
                stack.push(x);
            }
            
            else
            {
                stack.push(Double.parseDouble(s));
            }
        } //end for
        return stack.poll();
    }//end evaluate
	
	public void readFromFile(int name)
	{
		int count=1;
		double expOutput=0;
		double eval=0;
		
		String filename=" ";
		
		if(name==1)
			filename="src/Function1.txt";
		if(name==2)
			filename="src/Function2.txt";
		if(name==3)
			filename="src/Function3.txt";
		
		try
		{
			Scanner read=new Scanner(new FileReader(filename));
			while(read.hasNext())
			{
				expOutput=read.nextDouble();
				eval=evaluate(count);
				double error=Math.abs(eval-expOutput);
				rawFitness+=error;
				if(error<0.001)
					hitsRatio++;
				count++;
			}
			read.close();
		}
		
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}

	public void displayTree()
	{
		for(int i=0;i<tree.length;i++)
		{
			System.out.print(tree[i]);
		}
		
	}
}
